def count_in_list(lst, value):
    """Return how many times value appears in lst."""
    return lst.count(value)